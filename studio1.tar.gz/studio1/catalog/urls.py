from django.urls import re_path
from . import views
from .views import BBLoginView



urlpatterns = [
    re_path(r'^$', views.index, name='index'),
    re_path('accounts/login', BBLoginView.as_view(), name='login')
]
