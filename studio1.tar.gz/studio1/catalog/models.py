from django.db import models
import uuid


# Create your models here.

class Category(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4)
    name = models.CharField(max_length=200)

    def __str__(self):
        return

class Status(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4)
    name = models.CharField(max_length=200)

    def __str__(self):
        return


class User(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4)
    fio = models.CharField(max_length=200)
    login = models.CharField(max_length=200)
    email = models.CharField(max_length=200)
    password = models.CharField(max_length=200)

    def __str__(self):
        return

class Order(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4)
    photo = models.CharField(max_length=200)
    name = models.CharField(max_length=200)
    description = models.CharField(max_length=200)
    category_id = models.ForeignKey('Category', on_delete=models.SET_NULL, null=True)
    user_id = models.ForeignKey('User', on_delete=models.SET_NULL, null=True)
    status_id = models.ForeignKey('Status', on_delete=models.SET_NULL, null=True)
    date = models.DateField(null=True, blank=True)

    def __str__(self):
        return


class Admin (models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4)
    name = models.CharField(max_length=200)
    REQUIRED_FIELDS = ('Admin',)
    USERNAME_FIELD = ('name', 'id')


