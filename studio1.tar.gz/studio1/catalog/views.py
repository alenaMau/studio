from django.shortcuts import render
from django.contrib.auth.views import LoginView
from django.contrib.auth.decorators import login_required

# Create your views here.

def index(request):
    return render(request, 'main/index.html')

class BBLoginView(LoginView):
   template_name = 'main/login.html'


@login_required
def account(required):
    return render(required, 'main/profile.html')
