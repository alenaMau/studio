from django.contrib import admin
from .models import Admin



admin.site.register(Admin)
# Register your models here.
